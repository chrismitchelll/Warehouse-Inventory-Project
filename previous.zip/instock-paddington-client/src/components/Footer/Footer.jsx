import React from "react";
import "./footer.scss";

export const Footer = () => {
  return (
    <footer className="footer">© InStock Inc. All Rights Reserved.</footer>
  );
};
